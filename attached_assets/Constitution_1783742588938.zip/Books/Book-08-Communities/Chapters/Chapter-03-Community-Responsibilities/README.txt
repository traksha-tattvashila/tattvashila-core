# Chapter 3 — Community Responsibilities

## Purpose

This chapter establishes the constitutional responsibilities of constitutional communities within Tattvashila.

It defines the constitutional obligations owed by every constitutional community to the Institution, its participants, and future generations, ensuring that every community faithfully advances the constitutional purpose of Tattvashila.

Community responsibilities exist to preserve constitutional integrity, institutional continuity, constitutional unity, and responsible stewardship.

---

## Scope

This chapter defines:

- Constitutional responsibilities of communities.
- Institutional responsibilities.
- Responsibilities toward participants.
- Constitutional accountability of communities.
- Constitutional principles governing community responsibilities.

---

## Dependencies

This chapter derives its authority from:

- Book I — Purpose and Vision.
- Book II — Institutional Structure.
- Book III — Identity.
- Book IV — Knowledge and Record.
- Book V — Participation.
- Book VI — Trust and Reputation.
- Book VII — Communication.
- Book VIII, Chapters 1–2.

Its provisions govern every constitutional community recognized under this Constitution.

---

## Status

Discovery: Complete

Questions: Resolved

Architecture: Frozen

Drafting: Ready

Review: Pending

---

## Source

This chapter is derived from the approved Discovery, Constitutional Questions Register, Architecture, Books I–VIII, the Constitutional Style Guide, and the Constitutional Interpretation & Validation Standard.