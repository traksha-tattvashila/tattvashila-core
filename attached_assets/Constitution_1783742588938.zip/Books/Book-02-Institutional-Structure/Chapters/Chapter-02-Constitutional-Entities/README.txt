Chapter 2 — Constitutional Entities

Purpose

This chapter establishes the constitutional entities that may exist under Tattvashila.

It defines the constitutional basis upon which entities are established, their relationship with the Institution, and the principles governing their existence within the constitutional framework.

This chapter does not establish individual entities. Rather, it establishes the constitutional principles applicable to every present and future entity created under Tattvashila.

---

Scope

This chapter defines:

- The meaning of a constitutional entity.
- The constitutional basis for establishing entities.
- The relationship between the Institution and its entities.
- The constitutional obligations shared by all entities.
- The distinction between constitutional entities and operational structures.

---

Dependencies

This chapter derives its authority from:

- Book I — Purpose and Vision.
- Book II, Chapter 1 — The Constitutional Nature of the Institution.

Its provisions shall guide the interpretation of every constitutional entity established under Tattvashila.

---

Status

Discovery: Complete

Questions: Resolved

Architecture: Frozen

Drafting: Ready

Review: Pending

---

Source

This chapter is derived from the approved Discovery, Constitutional Questions Register, Architecture, Book I, Chapter 1 of Book II, the Constitutional Style Guide, and the Constitutional Interpretation & Validation Standard.