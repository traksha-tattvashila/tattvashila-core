Chapter 1 — The Constitutional Nature of the Institution

Purpose

This chapter establishes the constitutional nature of Tattvashila as an Institution.

It defines the constitutional identity of the Institution, the source of its legitimacy, and the constitutional principles that distinguish it from temporary organisations, projects, legal entities, or operational structures.

This chapter serves as the constitutional foundation upon which the remainder of Book II is built.

---

Scope

This chapter defines:

- The constitutional identity of Tattvashila.
- The constitutional basis of the Institution.
- The source of constitutional legitimacy.
- The distinction between constitutional identity and legal form.
- The permanence of the Institution beyond temporary organisational arrangements.

---

Dependencies

This chapter derives its authority from the constitutional principles established in Book I.

Its provisions shall guide the interpretation of every subsequent chapter in Book II.

---

Status

Discovery: Complete

Questions: Resolved

Architecture: Frozen

Drafting: Ready

Review: Pending

---

Source

This chapter is derived from the approved Discovery, Constitutional Questions Register, Architecture, Book I, the Constitutional Style Guide, and the Constitutional Interpretation & Validation Standard.