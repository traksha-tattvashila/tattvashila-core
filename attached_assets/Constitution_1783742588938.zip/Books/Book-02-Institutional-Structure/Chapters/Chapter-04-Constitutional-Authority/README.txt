Chapter 4 — Constitutional Authority

Purpose

This chapter establishes the constitutional principles governing authority within Tattvashila.

It defines the source, exercise, delegation, and constitutional limits of authority while ensuring that all authority remains subordinate to the Constitution.

This chapter prevents the concentration, misuse, or arbitrary exercise of authority within the Institution.

---

Scope

This chapter defines:

- The constitutional source of authority.
- Constitutional authority and delegated authority.
- The limits of constitutional authority.
- Non-delegable constitutional authority.
- Constitutional accountability in the exercise of authority.

---

Dependencies

This chapter derives its authority from:

- Book I — Purpose and Vision.
- Book II, Chapter 1 — The Constitutional Nature of the Institution.
- Book II, Chapter 2 — Constitutional Entities.
- Book II, Chapter 3 — Institutional Relationships.

Its provisions shall govern the exercise of authority throughout the Institution.

---

Status

Discovery: Complete

Questions: Resolved

Architecture: Frozen

Drafting: Ready

Review: Pending

---

Source

This chapter is derived from the approved Discovery, Constitutional Questions Register, Architecture, Book I, the preceding chapters of Book II, the Constitutional Style Guide, and the Constitutional Interpretation & Validation Standard.