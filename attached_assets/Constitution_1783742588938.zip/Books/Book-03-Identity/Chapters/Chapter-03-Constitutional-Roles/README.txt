Chapter 3 — Constitutional Roles

Purpose

This chapter establishes the constitutional principles governing roles within Tattvashila.

It defines constitutional roles, their relationship to constitutional identity and responsibilities, and the principles governing their exercise.

Constitutional roles exist to serve the constitutional purpose of the Institution and shall remain subordinate to this Constitution.

---

Scope

This chapter defines:

- Constitutional roles.
- Assignment of constitutional roles.
- Relationship between roles and responsibilities.
- Multiple constitutional roles.
- Constitutional limitations governing roles.

---

Dependencies

This chapter derives its authority from:

- Book I — Purpose and Vision.
- Book II — Institutional Structure.
- Book III, Chapters 1 and 2.

Its provisions shall govern every constitutional role established within Tattvashila.

---

Status

Discovery: Complete

Questions: Resolved

Architecture: Frozen

Drafting: Ready

Review: Pending

---

Source

This chapter is derived from the approved Discovery, Constitutional Questions Register, Architecture, Books I and II, the preceding chapters of Book III, the Constitutional Style Guide, and the Constitutional Interpretation & Validation Standard.