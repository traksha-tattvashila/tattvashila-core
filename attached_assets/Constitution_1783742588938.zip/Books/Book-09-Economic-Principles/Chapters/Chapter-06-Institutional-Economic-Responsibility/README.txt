# Chapter 6 — Institutional Economic Responsibility

## Purpose

This chapter establishes the constitutional principles governing the economic responsibilities of Tattvashila and its constitutional institutions.

It defines how constitutional authority shall exercise economic responsibility, ensuring that economic decisions preserve constitutional purpose, institutional continuity, stewardship, accountability, and long-term sustainability.

Institutional economic responsibility exists to ensure that every constitutional economic decision serves the Constitution before any individual or institutional interest.

---

## Scope

This chapter defines:

- Institutional economic responsibility.
- Constitutional economic decision-making.
- Accountability in economic administration.
- Economic responsibility toward constitutional resources.
- Constitutional principles governing institutional economic responsibility.

---

## Dependencies

This chapter derives its authority from:

- Book I — Purpose and Vision.
- Book II — Institutional Structure.
- Book III — Identity.
- Book IV — Knowledge and Record.
- Book V — Participation.
- Book VI — Trust and Reputation.
- Book VII — Communication.
- Book VIII — Communities.
- Book IX, Chapters 1–5.

Its provisions govern every constitutional institution, governing body, constitutional office, and constitutional entity exercising economic responsibilities.

---

## Status

Discovery: Complete

Questions: Resolved

Architecture: Frozen

Drafting: Ready

Review: Pending

---

## Source

This chapter is derived from the approved Discovery, Constitutional Questions Register, Architecture, Books I–IX, the Constitutional Style Guide, and the Constitutional Interpretation & Validation Standard.