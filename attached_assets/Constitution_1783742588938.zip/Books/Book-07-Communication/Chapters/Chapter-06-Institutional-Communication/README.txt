# Chapter 6 — Institutional Communication

## Purpose

This chapter establishes the constitutional principles governing official communication within Tattvashila.

It defines institutional communication, the constitutional authority governing such communication, and the principles ensuring that official communications preserve constitutional integrity, accountability, continuity, and institutional trust.

Institutional communication exists to faithfully communicate the constitutional position of Tattvashila rather than the personal opinions of individuals.

---

## Scope

This chapter defines:

- Institutional communication.
- Official constitutional communication.
- Constitutional authority for communication.
- Preservation of institutional communication.
- Constitutional principles governing institutional communication.

---

## Dependencies

This chapter derives its authority from:

- Book I — Purpose and Vision.
- Book II — Institutional Structure.
- Book III — Identity.
- Book IV — Knowledge and Record.
- Book V — Participation.
- Book VI — Trust and Reputation.
- Book VII, Chapters 1–5.

Its provisions govern every official constitutional communication issued by or on behalf of Tattvashila.

---

## Status

Discovery: Complete

Questions: Resolved

Architecture: Frozen

Drafting: Ready

Review: Pending

---

## Source

This chapter is derived from the approved Discovery, Constitutional Questions Register, Architecture, Books I–VII, the Constitutional Style Guide, and the Constitutional Interpretation & Validation Standard.